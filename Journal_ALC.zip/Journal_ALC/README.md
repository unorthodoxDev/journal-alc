Simple Notes App

Source code till 10 parts of tutorials.

Note: The Firebase Service Json is deleted, so you have to your own json in app dir.

Watch playlist:
https://www.youtube.com/playlist?list=PLgqXWQqMyp4-NdaZDXCz7tVpN2LeqhV2G
